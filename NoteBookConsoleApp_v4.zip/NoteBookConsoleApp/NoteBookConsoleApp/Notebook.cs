﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NoteBookConsoleApp
{
    /// <summary>
    ///     a class called NoteBook that has methods
    /// </summary>
    internal class Notebook
    {
        /// <summary>
        ///     the const string var called IntroMessage
        /// </summary>
        public const string IntroMessage = "Welcome to the Console App that is a NoteBook v1";

        /// <summary>
        ///     the const string var called OutroMessage
        /// </summary>
        public const string OutroMessage = "Dev says: 'Thanks for beta viewing v1' ";

        List<IPageable> pages = new List<IPageable>();
        public delegate void SimpleFunction(string command);
        public delegate void BooleanFunction(bool isOn);
        public event SimpleFunction ItemAdded, ItemRemoved, InputBadCommand;
        public event BooleanFunction loggingToggled;
        private Dictionary<string,SimpleFunction> commandLineArgs = new Dictionary<string, SimpleFunction>();
        public readonly string show = "show", _new = "new",delete = "delete",log = "logger";
        public SimpleFunction this[string command] {
            get {
                return commandLineArgs[command];
            }
        }
        public Notebook()
        {
            commandLineArgs.Add(show, Show);
            commandLineArgs.Add(_new, New);
            commandLineArgs.Add(delete, Delete);
            commandLineArgs.Add(log, Log);
        }
        /// <summary>
        ///     Creates a new notebook with Input keywords for commands
        /// </summary>
        /// <param name="commandLineKeywords">
        ///     index 0 = show, 1 = new, 2 = delete
        /// </param>
        public Notebook(params string[] commandLineKeywords) : this ()
        {
            for (int i = 0; i < commandLineKeywords.Length; i++)
            {
                if (commandLineKeywords[i] == "")
                {
                    continue;
                }
                switch (i)
                {
                    case 0:
                        commandLineArgs.Remove(show);
                        commandLineArgs.Add(show = commandLineKeywords[i],Show);
                        break;

                    case 1:
                        commandLineArgs.Remove(_new);
                        commandLineArgs.Add(_new = commandLineKeywords[i], New);
                        break;

                    case 2:
                        commandLineArgs.Remove(delete);
                        commandLineArgs.Add(delete = commandLineKeywords[i], Delete);
                       break;
                }
            }

        }
        private void Show(string command)
        {
            switch (command)
            {
                case "":
                    Console.WriteLine("Show commands:");
                    Console.WriteLine("pages        show all pages");
                    Console.WriteLine("id of page       show a page with the specific id");
                    Console.WriteLine("image        create a new image page");
                    break;

                case "pages":
                    Console.WriteLine("/--------------------Pages--------------------\\");
                    for (int i = 0; i < pages.Count; ++i)
                    {
                        Console.WriteLine($"ID: {i}; {pages[i].MyData.title}");
                    }
                    break;

                default:
                    int number;
                    if(int.TryParse(command, out number))
                    {
                        Console.WriteLine($"showing page {number}");

                        if(number < pages.Count)
                        {
                            pages[number].Output();
                        }else
                        {
                            if (InputBadCommand != null)
                            {
                                InputBadCommand("your number was outside of the range of pages please try again");
                            }
                        }
                    }
                    else
                    {
                        if (InputBadCommand != null)
                        {
                            InputBadCommand("you didn't enter pages or valid number please try again");
                        }
                    }
                    break;
            }
        }
        private void New(string command)
        {
            switch (command)
            {
                case "":
                    Console.WriteLine("New commands:");
                    Console.WriteLine("message      create a new message page");
                    Console.WriteLine("list     create a new list page");
                    Console.WriteLine("image    create a new image page");
                    break;

                case "message":
                    pages.Add(new TexualMessage().Input());
                    if(ItemAdded != null)
                    {
                        ItemAdded("Texual Message");
                    }
                    break;

                case "list":
                    pages.Add(new MessageList().Input());
                    if (ItemAdded != null)
                    {
                        ItemAdded("Message List");
                    }
                    break;

                case "image":
                    pages.Add(new Image().Input());
                    if (ItemAdded != null)
                    {
                        ItemAdded("Image");
                    }
                    break;
                default:
                    if (InputBadCommand != null)
                    {
                        InputBadCommand("you didn't enter message, list, or image please try again");
                    }
                    break;
            }
        }
        private void Delete(string command)
        {
            switch (command)
            {
                case "":
                    Console.WriteLine("Delete commands:");
                    Console.WriteLine("all      create a new message page");
                    Console.WriteLine("id of page     create a new list page");
                    break;

                case "all":
                    pages.Clear();
                    if (ItemRemoved != null)
                    {
                        ItemRemoved("");
                    }
                    
                    break;

                default:
                    int number;
                    if(int.TryParse(command, out number))
                    {
                        if(number < pages.Count)
                        {
                            pages.RemoveAt(number);
                            if (ItemRemoved != null)
                            {
                                ItemRemoved(number + "");
                            }
                        }
                        else
                        {
                            if (InputBadCommand != null)
                            {
                                InputBadCommand("your number was outside the range of pages please try again");
                            }
                        }
                    }
                    else
                    {
                        if (InputBadCommand != null)
                        {
                            InputBadCommand("your number is outside the range of pages please try again");
                        }
                    }
                break;
            }
        }
        private void Log(string command)
        {
            switch (command)
            {
                case "":
                    Console.WriteLine("Logger commands:");
                    Console.WriteLine("on       turn logger on");
                    Console.WriteLine("off      turn logger off");
                    break;
                case "on":
                    if(loggingToggled != null)
                    {
                        loggingToggled(true);
                    }
                    break;
                case "off":
                    if (loggingToggled != null)
                    {
                        loggingToggled(false);
                    }
                    break;
                default :
                    if(InputBadCommand != null)
                    {
                        InputBadCommand("please enter on or off after inputting the log command");
                    }
                    break;
            }

        }
    }
}
